package com.ob.ui;

import java.util.List;
import java.util.Scanner;

import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.ServiceTracker;
import com.ob.service.IOnlineBankingService;
import com.ob.service.OnlineBankingService;

public class OnlineBanking {
	
	 static Scanner scanner=null;
	 static IOnlineBankingService onlineBankingService=null;
	 static CustomerSignUp customerSignUp=null;
	
	public OnlineBanking() {
		onlineBankingService=new OnlineBankingService();
	}
	
	/*  Main Method  */
	public static void main(String[] args)
	{
		
		scanner=new Scanner(System.in);
		
		/* do while loop for Infinity  */
		
		do {
		System.out.println("WELCOME TO THE ONLINE BANKING");
		System.out.println("..................................");
		System.out.println("1  ------>  CUSTOMER LOGIN  ");
		System.out.println("2  ------>  ADMINISTRATION LOGIN ");
		System.out.println("..................................");
		
		int option=scanner.nextInt();
		switch (option) {
		case 1:
			//CUSTOMER LOGIN
			System.out.println("WELCOME TO CUSTOMER LOGIN");
			customerLoginPage();
			break;

		case 2:
			//ADMIN LOGIN
			System.out.println("WELCOME TO ADMINISTRATION LOGIN");
			administrationLoginPage();
			break;
			
        default:
        	//BY DEFAULT
            System.out.println("EXIT");
			System.exit(0);
			break;
		}
		}while(true);
	}
	
	/* customer   sign in and sign up  */
	
	public static void customerLoginPage() {
		
		System.out.println("PRESS 1 FOR SIGN IN AND 2 FOR SIGN UP");
		int customerSignIn=scanner.nextInt();
		switch (customerSignIn) {
		case 1:
			int accountId=0;
			int count=0;
			do {
		     System.out.println("ENTER YOUR USERID");
		     int customerUserId=scanner.nextInt();
		
		     System.out.println("ENTER YOUR PASSWORD");
		     String customerPassword=scanner.nextLine();
		     
		     /* retrive customer account id using username and password */
		/* pass it in customer Login below */
		     accountId=onlineBankingService.validateCustomerLoginDetails(customerUserId,customerPassword);
		     
		     if(accountId==0) {
		    	 System.out.println("INVALID USERID AND PASSWORD");
		    	 System.out.println("PLEASE ENTER VALID USERID AND PASSWORD");
		    	 count++;
		    	 
		     }else {
		     
		     customerLogin(accountId);
		     count=3;
		     }
			}while(accountId==0&&count<3);
			
		  break;
		
		case 2:
		//New  User For SignUP
		     System.out.println("SIGN UP");
		     String customerSignUp=scanner.nextLine();
		     
		     customerSignUp();
		
		  break;
		
		default:
			System.out.println("PLEASE ENTER CORRECT OPTION");
			break;
		}
		
		
	}
	public static void administrationLoginPage() {
		int count=0;
		do {
		System.out.println("ENTER YOUR USER ID");
		int adminuserid=scanner.nextInt();
		
		
		System.out.println("ENTER YOUR PASSWORD");
		String adminpassword=scanner.nextLine();
		
		
		if(adminuserid==1234&&adminpassword=="admin") {
		
		administrationLogin();
		count=3;
		}else {
			System.out.println("ENTER VALID LOGIN DETAILS");
			count++;
		}
		}while(count<3);
	}
	
	public static void customerLogin(int accountId) {
		
		System.out.println("PLEASE SELECT THE SERVICES");
		System.out.println("1  --->  ACCOUNT BALANCE");
		System.out.println("2  --->  MINI/DETAILED STATEMENTS");
		System.out.println("3  --->  ADDRESS CHANGE REQUEST");
		System.out.println("4  --->  MOBILE NO. CHANGE REQUEST");
		System.out.println("5  --->  CHEQUE BOOK REQUEST");
		System.out.println("6  --->  SERVICE REQUEST TRACKER");
		System.out.println("7  --->  FUND TRANSFER");
		System.out.println("8  --->  CHANGE PASSWORD");
		
		int custoption=scanner.nextInt();
		
		String description=null;
		switch (custoption) {
		
		case 1:
		    int acc_bal=onlineBankingService.customerAccountBalance(accountId);
			System.out.println("YOUR ACCOUNT BALANCE  :  "+acc_bal);
			break;
			
        case 2:
        	/*     mini and detailed transaction    */
			
			break;
			
        case 3:
        	System.out.println("ENTER YOUR NEW ADDRESS");
        	description=scanner.next();
        	onlineBankingService.Request(accountId,description);
	        System.out.println("REQUEST PROCESSED");
	        break;
	        
        case 4:
        	System.out.println("ENTER YOUR NEW MOBILE NUMBER");
        	description=scanner.next();
        	onlineBankingService.Request(accountId,description);
	        System.out.println("REQUEST PROCESSED");
	
	        break;
	        
        case 5:
        	//int acc_id=serobj.CustomerAccountId();
        	description="NEW CHEQUEBOOK";
        	onlineBankingService.Request(accountId,description);
	        System.out.println("REQUEST PROCESSED");
	
	        break;
	        
        case 6:
        	
        	List<ServiceTracker> servicetracker=null;
			
				servicetracker = onlineBankingService.retrieveServiceTrackerByAccountId(accountId);
		
			
			for(ServiceTracker st:servicetracker)
			{
			System.out.println(st);	
			}
	 
	        break;
	        
        case 7:
        	int senderAccountNum=accountId;
        	System.out.println("ENETER THE PAYEE ACCOUNT");
        	int payeeAccountNum=scanner.nextInt();
        	System.out.println("ENTER THE TRANSACTION PASSWORD");
        	String transpwd=scanner.next();
        	System.out.println("ENTER THE AMOUNT");
        	int transactionAmount=scanner.nextInt();
        	System.out.println("TRANSACTION TYPE");
        	System.out.println(" 1  --->  NEFT");
        	System.out.println(" 2  --->  RTGS");
        	System.out.println(" 3  --->  IMPS");
        	int choice=scanner.nextInt();
        	switch (choice) {
			case 1:
				/*    update amount in payee and payer  */
				/*     enter neft in transaction type  */
				System.out.println("NEFT TRANSACTION SUCCESSFUL");
				break;
				
				
			case 2:
				/*    update amount in payee and payer  */
				/*     enter RTGS in transaction type  */
				System.out.println("RTGS TRANSACTION SUCCESSFUL");
				break;
				
			case 3:
				/*    update amount in payee and payer  */
				/*     enter imps in transaction type  */
				System.out.println("IMPS TRANSACTION SUCCESSFUL");
				break;

			default:
				System.out.println("INVALID CHOICE . PLEASE ENTER CORRECT OPTION");
				break;
			}
        	
       	 
	        break;
	     
        
        case 8:
        	System.out.println("CREATE A NEW PASSWORD FOR USERLOGIN");
        	String loginPassword=scanner.next();
        	onlineBankingService.updateLoginPassword(accountId,loginPassword);
        	/*    provide  status       */
	
	        break;
        
		default:
			break;
		}
		
		
	}
	public static void administrationLogin() {
		System.out.println("PLEASE SELECT THE SERVICES");
		System.out.println("1  --->  CREATE NEW ACCOUNT");
		System.out.println("2  --->  VIEW TRANSACTION");
		int adminoption=scanner.nextInt();
		switch (adminoption) {
		case 1:
			NewAccount newcustomer=new NewAccount();
			
			System.out.println("PLEASE ENTER YOUR DETAILS");
			System.out.println("ENTER YOUR NAME ");
			String name=scanner.nextLine();
			newcustomer.setCustomerName(name);
			
			System.out.println("ENTER ADDRESS DETAILS");
			String address=scanner.nextLine();
			newcustomer.setCustomerAddress(address);
			
			System.out.println("ENTER MOBILE NUMBER");
			String mob_num=scanner.nextLine();
			newcustomer.setCustomerMobNum(mob_num);
			
			System.out.println("ENTER EMAIL ID");
			String email=scanner.nextLine();
			newcustomer.setCustomerEmail(email);
			
			System.out.println("ENTER ACCOUNT TYPE");
			String acc_type=scanner.nextLine();
			newcustomer.setAccountType(acc_type);
			
			int id=generateAccountId();
			System.out.println("YOUR ACCOUNT ID GENERATED : "+id);
			newcustomer.setAccountId(id);
			
			System.out.println("OPENING BALANCE");
			String opening_bal=scanner.nextLine();
			newcustomer.setAccountBalance(opening_bal);
			
			onlineBankingService.createNewAccount(newcustomer);
			
			System.out.println("WELCOME TO ****** BANK");
			
			break;
        
        case 2:
        	System.out.println("ENTER THE ACCOUNT NUMBER");
        	String acc_num=scanner.nextLine();
        	System.out.println("  TRANSACTION PERIOD  ");
        	System.out.println(" PRESS 1  --->  FOR 1 DAY ");
        	System.out.println(" PRESS 2  --->  FOR 1 MONTH ");
        	System.out.println(" PRESS 3  --->  FOR 1 YEAR ");
        	System.out.println(" PRESS 4  --->  ALL TRANSACTION");
        	
			
			break;
		default:
			break;
		}
		
	}
	
	
	public static void customerSignUp() {
		
		 customerSignUp=new CustomerSignUp();
		
	/*	System.out.println("ENTER THE ACCOUNT ID");
		int accountId=scanner.nextInt();
		customerSignUp.setAccountId(accountId);*/
		 int userId;
		do{
		System.out.println("ENTER USER ID");
		userId=scanner.nextInt();
		customerSignUp.setUserId(userId);
		}while(onlineBankingService.validateUserId(userId)==false);
		
		
		String loginPassword;
		do{
		System.out.println("CREATE PASSWORD");
		 loginPassword=scanner.next();
		customerSignUp.setLoginPassword(loginPassword);
		}while(onlineBankingService.validatePassword(loginPassword)==false);
		
		String secretQuestion;
		
		do{
		System.out.println("SECURITY QUESTION");
		System.out.println("What is Your Date of Birth");
		secretQuestion=scanner.next();
		customerSignUp.setSecretQuestion(secretQuestion);
		}while(onlineBankingService.validateSecretQuestion(secretQuestion)==false);
		
		String transactionPassword;
		do{
		System.out.println("CREATE TRANSACTION PASSWORD");
		transactionPassword=scanner.next();
		customerSignUp.setTransactionPassword(transactionPassword);
		}while(onlineBankingService.validateTransactionPassword(transactionPassword));
		
		System.out.println("CREATE LOCK STATUS ****************************");
		String lockStatus=scanner.next();
		customerSignUp.setLockStatus(lockStatus);
		
		onlineBankingService.customerSignUp(customerSignUp);
		 
	}
	public static int generateAccountId() {
		int accountId=(int)(Math.random()*1000000000);
		return accountId;
	}

}
