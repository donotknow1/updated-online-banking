package com.ob.dao;


import java.util.List;

import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.ServiceTracker;


public class OnlineBankingDao implements IOnlineBankingDao{
	
	@Override
	public int validateCustomerLoginDetails(int custuserid, String custpassword) {
		
		/* retrive accountid if custuserid and custpassword exit otherwise return 0 */
		
		return 0;
	}
	
	@Override
	public int customerAccountBalance(int accountId) {
		int accountbal=0;
		/*  retrive customer account balance  from table   */
		return accountbal;
	}
	
	@Override
	public void Request(int acc_id, String description) {
		/*  insert request into service tracker table */
		
	}
	@Override
	public List<ServiceTracker> retrieveServiceTrackerByAccountId(int accountId){
		
		/*    retrive all column from servicetracker using accountid  */
		
		
		return null;
	}
	
	@Override
	public void createNewAccount(NewAccount newcustomer) {
		/* add new customer data to (1)account master and (2)customer tables*/
		
	}
	@Override	
public void customerSignUp(CustomerSignUp obs) {
		
		/* add data to user table in database */
		
		
	}
@Override
public int updateLoginPassword(int accountid,String loginPassword) {
	
	/*update password in user table using accountid  */
	return 0;
}
	
	
	
	
	
	
	
	
	
	

	

	

	

}
