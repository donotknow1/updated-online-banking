package com.ob.service;

import java.util.List;

import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.ServiceTracker;

public interface IOnlineBankingService {
	
	abstract int validateCustomerLoginDetails(int custuserid, String custpassword);
	abstract int customerAccountBalance(int accountId);
	abstract void Request(int acc_id, String description);
	abstract List<ServiceTracker> retrieveServiceTrackerByAccountId(int accountId);
	abstract int updateLoginPassword(int accountid,String loginPassword);
	abstract void createNewAccount(NewAccount newcustomer);
	abstract void customerSignUp(CustomerSignUp csu);
	
	//validating user details
	abstract boolean validateUserId(int userId);
	abstract boolean validatePassword(String loginPassword);
	abstract boolean validateSecretQuestion(String secretQuestion);
	abstract boolean validateTransactionPassword(String transactionPassword);
	

}
